 Reproducible Package for "Semantic Drift and Term Politics: Institutional Reconfiguration of 'Loyalty–Righteousness–Benevolence' in East Asia (1600–1900)"

This repository provides all data, scripts, and documentation to reproduce the analyses in the study:  
"Semantic Drift and Term Politics: Institutional Reconfiguration of 'Loyalty–Righteousness–Benevolence' in East Asia (1600–1900)".

It includes preprocessed corpora, time-aligned BERT vectors, computed metrics (ΔCosine, ND), and KWIC contextual data for key terms (“忠”, “义”, “仁”). This package aims to ensure full transparency and reproducibility of results for academic review and future research.

---

 Repository Structure

Reproducible_Package_1600-1900/
│
├── corpus/  Text corpora for each time slice (UTF-8, plain text)
│ ├── 1600-1625_shido.txt
│ ├── 1740-1765_hagakure.txt
│ ├── 1890_education_rescript.txt
│ └── ... (additional slices)
│
├── vectors/ Time-slice BERT vectors for key terms (saved as .npy)
│ ├── vectors_1600-1625.npy
│ ├── vectors_1740-1765.npy
│ └── vectors_1890.npy
│
├── data/  Computed results for analysis
│ ├── delta_cosine.csv # ΔCosine values per term per time slice
│ ├── nd_values.csv Neighborhood Density (ND) values
│ ├── kwic_1740.csv  KWIC contexts for 1740 slice
│ ├── kwic_1890.csv  KWIC contexts for 1890 slice
│ └── clusters_table7.csv  Semantic clustering data for Table 7
│
├── scripts/  Python scripts for data processing and analysis
│ ├── preprocess_texts.py  Corpus cleaning and preprocessing
│ ├── train_vectors.py  Time-aligned BERT training and vector extraction
│ ├── calc_delta_cosine.py  ΔCosine calculation
│ ├── calc_nd.py  Neighborhood Density (ND) computation
│ ├── kwic_extract.py  KWIC context extraction tool
│ └── utils.py Helper functions
│
├── methods/  Documentation of methodology
│ └── Methods.md  Detailed explanation of models, parameters, and formulas
│
├── logs/ Sample run logs for reproducibility
│ ├── run_log_bert.txt
│ ├── run_log_cosine.txt
│ └── run_log_kwic.txt
│
└── README.md  Project overview and reproduction guide

Requirements
Python**: 3.8+
Libraries:
  - 'transformers' (HuggingFace)
  - 'torch'
  - 'numpy'
  - 'pandas'
  - 'scikit-learn'
- Hardware: GPU recommended for BERT embedding (fallback to CPU supported)

Install dependencies:
bash
pip install -r requirements.txt
Reproduction Steps

    Prepare the corpus

        Place UTF-8 encoded texts in /corpus/ with filenames in the format YYYY-YYYY_title.txt.

    2.Preprocess texts
python scripts/preprocess_texts.py
3.Train BERT vectors (time-aligned by slice)
python scripts/train_vectors.py
4.Compute metrics
python scripts/calc_delta_cosine.py
python scripts/calc_nd.py
5.Extract KWIC contexts
python scripts/kwic_extract.py
Data Description

    ΔCosine: Measures semantic drift of target terms across time slices.

    ND (Neighborhood Density): Indicates semantic clustering stability.

    KWIC: Key Word in Context extracts for interpretive analysis.

    Vectors: Contextual BERT embeddings (768-dim, mean-pooled).
Citation

If you use this repository, please cite:

    [Sun Yang & Kang Yunqing], Semantic Drift and Term Politics: Institutional Reconfiguration of 'Loyalty–Righteousness–Benevolence' in East Asia (1600–1900), [Journal/Preprint], 2025.
Contact

For questions or collaboration:

    Author: [Sun Yang & Kang Yunqing]

    Email: [leileiluck666@163.com]

    Affiliation: [Harbin Normal University Guangdong University of Business and Technology]
