Methods

This document details the methodology used in the Reproducible_Package_1600-1900 project. It covers corpus preparation, time slicing, embedding generation with BERT, and the computation of semantic metrics (ΔCosine, Neighborhood Density), ensuring full reproducibility of our experiments.

1. Corpus Preparation
1.1 File Naming Convention

All text files in the /corpus/ directory follow this pattern:

<start_year>-<end_year>_<textname>.txt

For example:

    1600-1625_Shido.txt

    1876-1900_KyoikuChokugo.txt

1.2 Text Cleaning

Each text file is processed using preprocess_texts.py:

    Converted to UTF-8 encoding.

    Normalized whitespace and punctuation.

    Removed non-textual symbols (decorative or non-standard characters).

    Standardized full-width and half-width characters.

    Removed annotations, editorial notes, and irrelevant metadata.

2. Time Slicing
2.1 Slicing Logic

The corpus is divided into 14 time slices spanning 1600–1900. Each slice covers 25 years:
(1600–1625), (1626–1650), (1651–1675), (1676–1700),
(1701–1725), (1726–1750), (1751–1775), (1776–1800),
(1801–1825), (1826–1850), (1851–1875), (1876–1900)

This ensures a consistent historical comparison across time.
2.2 Integration per Slice

For each slice:

    All relevant texts are concatenated into a single document.

    Texts are labeled by their time slice for clear traceability.
3. BERT Embedding Generation
3.1 Model Selection

We use the Japanese BERT model:
cl-tohoku/bert-base-japanese
This model is trained on large-scale Japanese corpora, suitable for Edo-Meiji texts.
3.2 Processing Pipeline

    Tokenization using BertTokenizer.

    Embedding extraction using BertModel.

    Batch processing for long texts (split by 512 tokens).

    Extraction of embeddings for target keywords: 忠, 義, 仁.
3.3 Output Format

    Dimension: 768-d vectors.

    Output: For each slice, a .npy file is saved as a Python dictionary:

{
  "忠": <vector>,
  "義": <vector>,
  "仁": <vector>
}
Files are stored in /vectors/ as:vectors_<start_year>-<end_year>.npy

4. Semantic Metrics
4.1 ΔCosine

Definition:
ΔCosine measures the semantic shift of a keyword between two time slices:
ΔCosine=1−CosineSimilarity(vt1,vt2)

Where vt1vt1​ and vt2vt2​ are the embeddings of the keyword in different time slices.

4.2 Neighborhood Density (ND)

Definition:
ND measures the compactness of a keyword’s semantic neighborhood:
[ ND = \frac{1}{N} \sum_{i=1}^{N} CosineSimilarity(v_{target}, v_{neighbor_i}) \]
Where vneighborivneighbori​​ are the embeddings of the top-N nearest semantic neighbors.

Parameters:

    Top-N neighbors: 20

    Distance metric: Cosine similarity

5. KWIC (Key Word in Context) Extraction

Using kwic_extract.py, we extract ±20 token windows for each keyword to analyze context shifts across time slices. Outputs are stored as .csv files containing:

time_slice, keyword, left_context, keyword, right_context

6. Reproducibility

    All scripts are included in the /scripts/ directory:

        preprocess_texts.py (text cleaning)

        train_vectors.py (BERT embedding extraction)

        calc_delta_cosine.py (ΔCosine calculation)

        calc_nd.py (ND calculation)

        kwic_extract.py (KWIC context extraction)

    Logs: Each execution generates detailed logs in /logs/.

    Parameters: Fully documented in this file and script headers.

7. Software and Environment

    Python: 3.9+

    Libraries:

        transformers

        torch

        numpy

        pandas

        scikit-learn

    Hardware: GPU recommended for BERT embeddings.
This methodology ensures full transparency and reproducibility for cross-linguistic semantic drift analysis of 忠, 義, 仁 in East Asian historical corpora.