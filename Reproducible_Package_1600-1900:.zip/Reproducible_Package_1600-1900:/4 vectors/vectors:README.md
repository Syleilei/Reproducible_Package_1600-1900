vectors Directory

This directory contains BERT-based embedding vectors for the three key Confucian terms — 忠 (loyalty), 义 (righteousness), and 仁 (benevolence) — across 14 historical time slices from 1600 to 1900. These vectors serve as the basis for ΔCosine drift analysis, Neighborhood Density (ND) calculations, and KWIC-based context validation.

File Naming Convention
vectors_<start_year>-<end_year>.npy
<start_year>-<end_year>: The historical time slice (e.g., 1600-1625).

Each .npy file is a serialized Python dictionary where:

    Key: One of the target keywords (忠, 义, 仁).

    Value: A 768-dimensional NumPy array representing the contextualized BERT embedding of that term within the time slice (average-pooled over all occurrences).
Example:
{
    "忠": [0.123, -0.045, ..., 0.067],  #768-dim vector
    "义": [0.089,  0.021, ..., -0.034],
    "仁": [-0.055, 0.112, ..., 0.008]
}

Time Slices

The vectors are provided for 14 time slices:
1600–1625
1626–1650
1651–1675
1676–1700
1701–1725
1726–1750
1751–1775
1776–1800
1801–1825
1826–1850
1851–1875
1876–1900
Usage

To load the vectors in Python:

import numpy as np

vectors = np.load("vectors_1600-1625.npy", allow_pickle=True).item()
print(vectors["忠"])  # Access the vector for 忠 in 1600–1625

Notes

    Model: All vectors are generated using cl-tohoku/bert-base-japanese (pretrained Japanese BERT).

    Aggregation: Vectors represent the mean-pooled contextual embeddings of each keyword across all occurrences within the time slice.

    Preprocessing: All texts were cleaned (removal of non-textual symbols, OCR corrections) prior to embedding.

    Reproducibility: Scripts for generating these vectors are located in the scripts/ directory (train_vectors.py).
