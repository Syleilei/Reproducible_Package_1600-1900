

 /scripts/train_vectors.py
Function: Slice corpus, extract BERT embeddings for keywords, and export vectors for each time slice × keyword

import os
import numpy as np
import torch
from transformers import BertTokenizer, BertModel

========== PARAMETERS ==========
corpus_dir = "../corpus/"            Corpus directory
output_dir = "../vectors/"           Output directory for vectors
keywords = ["忠", "义", "仁"]         Keywords to extract
time_slices = [
    (1600,1625),(1626,1650),(1651,1675),(1676,1700),
    (1701,1725),(1726,1750),(1751,1775),(1776,1800),
    (1801,1825),(1826,1850),(1851,1875),(1876,1900)
]
bert_model = "cl-tohoku/bert-base-japanese"   Pretrained BERT model
device = "cuda" if torch.cuda.is_available() else "cpu"

os.makedirs(output_dir, exist_ok=True)

========== LOAD BERT ==========
tokenizer = BertTokenizer.from_pretrained(bert_model)
model = BertModel.from_pretrained(bert_model).to(device)
model.eval()

========== FUNCTION: Extract keyword vector ==========
def extract_keyword_vector(text, keyword):
    inputs = tokenizer(text, return_tensors="pt", truncation=True, max_length=512)
    inputs = {k: v.to(device) for k, v in inputs.items()}
    with torch.no_grad():
        outputs = model(**inputs)
    last_hidden = outputs.last_hidden_state.squeeze(0)
    tokens = tokenizer.convert_ids_to_tokens(inputs["input_ids"][0])
    vectors = [last_hidden[i].cpu().numpy() for i, tok in enumerate(tokens) if keyword in tok]
    if vectors:
        return np.mean(vectors, axis=0)  Average over all occurrences
    else:
        return np.zeros(768)  Return zero vector if keyword not found

========== MAIN PROCESS: Loop over time slices and export ==========
for start, end in time_slices:
    slice_texts = []
    for fname in os.listdir(corpus_dir):
        if fname.endswith(".txt") and f"{start}-{end}" in fname:
            with open(os.path.join(corpus_dir, fname), "r", encoding="utf-8") as f:
                slice_texts.append(f.read())
    combined_text = "\n".join(slice_texts)
    vectors = {}
    for kw in keywords:
        vectors[kw] = extract_keyword_vector(combined_text, kw)
    np.save(os.path.join(output_dir, f"vectors_{start}-{end}.npy"), vectors)
    print(f"[OK] Saved vectors for {start}-{end}")
