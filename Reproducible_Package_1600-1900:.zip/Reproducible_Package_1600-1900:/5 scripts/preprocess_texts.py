 /scripts/preprocess_texts.py
 Purpose: Clean and preprocess corpus text for modeling (UTF-8 safe)

 -*- coding: utf-8 -*-
import os
import re

 Input and output directories
input_dir = "../corpus_raw/"
output_dir = "../corpus/"
os.makedirs(output_dir, exist_ok=True)

def preprocess_text(text):
     Normalize spaces (collapse multiple spaces/tabs/newlines into one space)
    text = re.sub(r"\s+", " ", text)
     Remove annotation brackets and comments: Japanese/Chinese full-width brackets and Western brackets
    text = re.sub(r"［.*?］|\(.*?\)|（.*?）|\[.*?\]", "", text)
     Remove special symbols using Unicode escapes (safe for all environments)
    text = re.sub(
        r"[\u25A1\u25A0\u25C7\u25C6\u203B\u2606\u2605\u25CB\u25CF\u25B3\u25B2\u25BD\u25BC\u2026\u2025]", 
        "", 
        text
    )
     Remove any non-printable characters (keep basic Latin, CJK, and Japanese Kana)
    text = re.sub(r"[^\x20-\x7E\u4E00-\u9FFFぁ-んァ-ン]", "", text)
    return text.strip()

 Process all .txt files in the input directory
for fname in os.listdir(input_dir):
    if fname.endswith(".txt"):
        with open(os.path.join(input_dir, fname), "r", encoding="utf-8") as f:
            raw_text = f.read()
        cleaned = preprocess_text(raw_text)
        with open(os.path.join(output_dir, fname), "w", encoding="utf-8") as f:
            f.write(cleaned)
        print(f"[OK] {fname} processed and saved to {output_dir}")
