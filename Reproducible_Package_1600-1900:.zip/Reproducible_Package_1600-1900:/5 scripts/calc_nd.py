 /scripts/calc_nd.py
 Function: Calculate Neighborhood Distance (ND) between two time slices
 ND is computed using Jaccard distance between top-N nearest neighbors of keywords.

import os
import numpy as np
from sklearn.metrics import pairwise_distances
from typing import Dict, List, Tuple

 ========== Parameters ==========
vectors_dir = "../vectors/"            Directory of saved vectors (.npy files)
output_dir = "../data/"                Directory to save ND results
keywords = ["忠", "义", "仁"]           Target keywords
top_n = 20                             Number of nearest neighbors to consider

os.makedirs(output_dir, exist_ok=True)

 ========== Utility Functions ==========

def load_vectors(file_path: str) -> Dict[str, np.ndarray]:
    """
    Load keyword vectors from a .npy file.
    Args:
        file_path: Path to the .npy file.
    Returns:
        A dictionary: {keyword: vector}.
    """
    return np.load(file_path, allow_pickle=True).item()

def cosine_similarity_matrix(vectors: Dict[str, np.ndarray]) -> Tuple[List[str], np.ndarray]:
    """
    Build a cosine similarity matrix for all keywords in the dictionary.
    Args:
        vectors: Dictionary of vectors.
    Returns:
        labels: List of keywords.
        similarity_matrix: 2D numpy array of cosine similarities.
    """
    labels = list(vectors.keys())
    matrix = np.array([vectors[k] for k in labels])
    sim_matrix = 1 - pairwise_distances(matrix, metric='cosine')
    return labels, sim_matrix

def get_top_neighbors(sim_matrix: np.ndarray, labels: List[str], keyword: str, top_n: int) -> List[str]:
    """
    Get top-N nearest neighbors for a keyword.
    Args:
        sim_matrix: Cosine similarity matrix.
        labels: List of keywords in order.
        keyword: The target keyword.
        top_n: Number of neighbors to retrieve.
    Returns:
        A list of top-N neighbor keywords.
    """
    idx = labels.index(keyword)
    similarities = sim_matrix[idx]
    sorted_indices = np.argsort(similarities)[::-1]  # Sort by descending similarity
    top_indices = [i for i in sorted_indices if i != idx][:top_n]
    return [labels[i] for i in top_indices]

def jaccard_distance(set1: set, set2: set) -> float:
    """
    Compute Jaccard distance between two sets.
    Args:
        set1, set2: Sets of neighbors.
    Returns:
        Jaccard distance (1 - intersection / union).
    """
    intersection = len(set1 & set2)
    union = len(set1 | set2)
    return 1 - intersection / union if union > 0 else 1.0

 ========== Main Workflow ==========

 Collect all time slices
files = sorted([f for f in os.listdir(vectors_dir) if f.endswith(".npy")])

nd_results = {}

for i in range(1, len(files)):
    prev_file = os.path.join(vectors_dir, files[i - 1])
    curr_file = os.path.join(vectors_dir, files[i])
    
    prev_vectors = load_vectors(prev_file)
    curr_vectors = load_vectors(curr_file)
    
     Combine keys for similarity calculation
    combined_vectors = {**prev_vectors, **curr_vectors}
    labels, sim_matrix = cosine_similarity_matrix(combined_vectors)
    
    nd_results[f"{files[i - 1]} → {files[i]}"] = {}
    
    for kw in keywords:
        prev_neighbors = set(get_top_neighbors(sim_matrix, labels, kw, top_n))
        curr_neighbors = set(get_top_neighbors(sim_matrix, labels, kw, top_n))
        nd_value = jaccard_distance(prev_neighbors, curr_neighbors)
        nd_results[f"{files[i - 1]} → {files[i]}"][kw] = nd_value
    
    print(f"[OK] ND calculated for transition: {files[i - 1]} → {files[i]}")

 Save results
output_path = os.path.join(output_dir, "nd_results.npy")
np.save(output_path, nd_results)
print(f"[DONE] ND results saved to {output_path}")


