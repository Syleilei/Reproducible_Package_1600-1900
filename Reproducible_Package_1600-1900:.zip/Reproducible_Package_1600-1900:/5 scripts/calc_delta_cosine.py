/scripts/calc_delta_cosine.py
Function: Calculate ΔCosine between consecutive time slices for each keyword.
Input: .npy vector files (one per time slice)
Output: A CSV table containing ΔCosine values for each keyword across all time slices

import os
import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity

 ========== Parameters ==========
vectors_dir = "../vectors/"       Directory containing .npy vector files
output_file = "../data/delta_cosine.csv"   Output CSV file
keywords = ["忠", "义", "仁"]             Keywords
time_slices = [
    (1600,1625),(1626,1650),(1651,1675),(1676,1700),
    (1701,1725),(1726,1750),(1751,1775),(1776,1800),
    (1801,1825),(1826,1850),(1851,1875),(1876,1900)
]

os.makedirs(os.path.dirname(output_file), exist_ok=True)

========== Function: Load vectors ==========
def load_vectors(file_path):
    if os.path.exists(file_path):
        return np.load(file_path, allow_pickle=True).item()
    else:
        print(f"[Warning] Missing file: {file_path}")
        return None

 ========== Function: Calculate cosine distance ==========
def cosine_distance(vec1, vec2):
    if np.linalg.norm(vec1) == 0 or np.linalg.norm(vec2) == 0:
        return None
    return 1 - cosine_similarity([vec1], [vec2])[0][0]

========== Main Process ==========
results = {kw: [] for kw in keywords}

 Iterate through consecutive time slices
for i in range(1, len(time_slices)):
    prev_start, prev_end = time_slices[i-1]
    curr_start, curr_end = time_slices[i]
    
    prev_file = os.path.join(vectors_dir, f"vectors_{prev_start}-{prev_end}.npy")
    curr_file = os.path.join(vectors_dir, f"vectors_{curr_start}-{curr_end}.npy")
    
    prev_vectors = load_vectors(prev_file)
    curr_vectors = load_vectors(curr_file)
    
    for kw in keywords:
        if prev_vectors and curr_vectors:
            dist = cosine_distance(prev_vectors[kw], curr_vectors[kw])
        else:
            dist = None
        results[kw].append(dist)

========== Build DataFrame ==========
slice_labels = [f"{time_slices[i][0]}-{time_slices[i][1]}" for i in range(1, len(time_slices))]
df = pd.DataFrame(results, index=slice_labels)
df.index.name = "Time Slice"

========== Save Output ==========
df.to_csv(output_file, encoding="utf-8-sig")
print(f"[OK] ΔCosine table saved to {output_file}")
