 /scripts/kwic_extract.py
Function: Extract KWIC (Keyword in Context) for a list of keywords from corpus text files.
Input: Corpus files (.txt) organized by time slices (e.g., 1600-1625_filename.txt)
Output: A CSV file with KWIC results: time slice, filename, keyword, left context, keyword, right context

import os
import csv

 ========== Parameters ==========
corpus_dir = "../corpus/"              Directory containing corpus files
output_file = "../data/kwic_results.csv"   Output CSV file
keywords = ["忠", "义", "仁"]                 Keywords to search for
context_window = 20                     Number of characters before and after keyword
time_slices = [
    (1600,1625),(1626,1650),(1651,1675),(1676,1700),
    (1701,1725),(1726,1750),(1751,1775),(1776,1800),
    (1801,1825),(1826,1850),(1851,1875),(1876,1900)
]

os.makedirs(os.path.dirname(output_file), exist_ok=True)

 ========== Function: Determine time slice by filename ==========
def get_time_slice(filename):
    for start, end in time_slices:
        if f"{start}-{end}" in filename:
            return f"{start}-{end}"
    return "Unknown"

========== Function: Extract KWIC contexts ==========
def extract_kwic(text, keyword, window):
    results = []
    index = 0
    while index < len(text):
        index = text.find(keyword, index)
        if index == -1:
            break
        left_context = text[max(0, index - window):index]
        right_context = text[index + len(keyword):index + len(keyword) + window]
        results.append((left_context, keyword, right_context))
        index += len(keyword)
    return results

 ========== Main Process ==========
all_results = []

for fname in os.listdir(corpus_dir):
    if not fname.endswith(".txt"):
        continue
    time_slice = get_time_slice(fname)
    with open(os.path.join(corpus_dir, fname), "r", encoding="utf-8") as f:
        text = f.read()
    for kw in keywords:
        kwic_results = extract_kwic(text, kw, context_window)
        for left, kwd, right in kwic_results:
            all_results.append([time_slice, fname, kwd, left, right])

========== Save to CSV ==========
with open(output_file, "w", newline="", encoding="utf-8-sig") as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(["Time Slice", "File", "Keyword", "Left Context", "Right Context"])
    writer.writerows(all_results)

print(f"[OK] KWIC results saved to {output_file}")


