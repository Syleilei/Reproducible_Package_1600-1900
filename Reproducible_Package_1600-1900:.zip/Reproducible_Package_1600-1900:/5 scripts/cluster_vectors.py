# /scripts/cluster_vectors.py
 Function: Cluster keyword vectors using KMeans and export semantic clusters

import os
import numpy as np
from sklearn.cluster import KMeans
import json

 ======== Parameters ========
input_dir = "../vectors/"          Directory of .npy vector files
output_dir = "../clusters/"        Directory to save cluster results
keywords = ["忠", "义", "仁"]
n_clusters = 3                     Number of clusters
os.makedirs(output_dir, exist_ok=True)

 ======== Functions ========
def load_vectors():
    all_vectors = {}
    for fname in os.listdir(input_dir):
        if fname.endswith(".npy"):
            time_label = fname.replace("vectors_", "").replace(".npy", "")
            vectors = np.load(os.path.join(input_dir, fname), allow_pickle=True).item()
            all_vectors[time_label] = vectors
    return all_vectors

def cluster_vectors(vectors):
    matrix = np.vstack(list(vectors.values()))
    model = KMeans(n_clusters=n_clusters, random_state=42).fit(matrix)
    labels = {kw: int(label) for kw, label in zip(vectors.keys(), model.labels_)}
    return labels

 ======== Main process ========
all_vectors = load_vectors()

for time_slice, vectors in all_vectors.items():
    labels = cluster_vectors(vectors)
    out_path = os.path.join(output_dir, f"clusters_{time_slice}.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(labels, f, ensure_ascii=False, indent=2)
    print(f"[OK] Clusters saved: {out_path}")
